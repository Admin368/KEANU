You can obtain cryptlib 3.3.3 sources from Peter Gutmann's site
http://www.cs.auckland.ac.nz/~pgut001/cryptlib/

I've made few hacks in the code that enchance/modify SSH support.
To compile cryptlib for KpyM Telnet/SSH Server replace the original files with files in that directory and compile with KPYM_HACK macro defined.

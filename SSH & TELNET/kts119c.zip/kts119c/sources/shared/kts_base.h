#pragma once
#pragma warning (disable: 4127)
#pragma warning (disable: 4512)

#define STRING_INIT_SIZE	( 4 * 1024 )

HK-TELNET-SERVER

----------------------------

change dir :

cd[ENTER]
path[ENTER]

example :

cd[ENTER]
f:[ENTER]

----------------------------

for terminate connection :

exit[ENTER]

or 

logout[ENTER]